<h1 style="text-align: center;">Operating System Lab 2</h1>





<img src="E:\OperatingSystemFiles\OsLab2\uetlogo.png" style="zoom:80%;" />

​                                                                           



​                                                                            Session : 2022-2026

​                                                                                **Submitted by**:

​                                 Ramsha Shabbir                                                               2022-CS-205

​                                                                                **Submitted to**: 

​                                                                             Prof Numan Shafi





​                                                                **Department of Computer Science**

​                                                           **University of Engineering and Technology**







<h3 style="text-align: center;">Task 1</h3>



![](E:\OperatingSystemFiles\OsLab2\Screenshot 2024-02-01 061647.png)



**Description**

Firstly, we create a file named "19f-XXXX.txt" using the touch command, and subsequently, we populate it with 10 lines using the nano text editor. Simultaneously, a second file, "ramsha.txt," is created using the touch command, followed by the addition of 10 lines through the nano editor. To merge the contents of both files, we utilize the cat command as follows: cat 19f-XXXX.txt ramsha.txt > merge_file.txt. This command concatenates the content of "19f-XXXX.txt" and "ramsha.txt" and redirects the result into a new file called "merge_file.txt." To confirm the successful merging, we employ the cat command once more to display the contents of "merge_file.txt." 



![](E:\OperatingSystemFiles\OsLab2\Screenshot 2024-02-01 061137.png)



**Description**

I open "19F-XXXX.txt" using nano, add ten lines, and save changes by pressing CTRL + X, confirming with Y, and then Enter.



![](E:\OperatingSystemFiles\OsLab2\Screenshot 2024-02-01 061415.png)



**Description**

I open "ramsha.txt" using nano, add ten lines, and save changes by pressing CTRL + X, confirming with Y, and then Enter.



![](E:\OperatingSystemFiles\OsLab2\Screenshot 2024-02-01 063148.png)



**Description**

 I performed several operations on files using commands in a straightforward manner. I utilized head -2 19f-XXXX.txt to display the first two lines of "19f-XXXX.txt" and tail -2 ramsha.txt to show the last two lines of "ramsha.txt." Employing grep, I searched for the string "hello" successfully but didn't find "2022-CS-205." Moving on to permissions, I executed chmod 717, granting full permissions to the owner, only execute to groups, and read/write/execute to others. The subsequent ls -l command revealed the permissions of files and folders. Later, I adjusted permissions with chmod 517, allowing owner read/execute but not write, and again checked permissions with ls -l. This encapsulates the operations performed concisely.



![](E:\OperatingSystemFiles\OsLab2\Screenshot 2024-02-01 063819.png)



**Description**

I made a new folder with mkdir, checked all files and folders using ls, then saw the current time with date, and wrapped up with a simple "Thank you" using echo.



<h3 style="text-align: center;">Task 2</h3>



![](E:\OperatingSystemFiles\OsLab2\Screenshot 2024-02-01 080447.png)



**Description**

Let's break down the given permissions (-rwxr-xr--):

- rwx: 111 in binary, which is 7 in decimal.
- r-x: 101 in binary, which is 5 in decimal.
- r--: 100 in binary, which is 4 in decimal.

So, the numeric representation for the given permissions is 754.I initiated the creation of a file named "19f-XXXX_OS-Lab_rules.txt" and enriched it with 10 lines of content using the Nano command. Subsequently, I meticulously assigned specific permissions to the file utilizing the numeric representation derived from the binary system. The permission configuration entailed providing the owner with read, write, and execute permissions (7), granting read and execute permissions (5) to the group, and affording others solely read permission (4). This numeric representation was then applied using the chmod command. As a final step, I employed the ls command, appending its output to a new file for a comprehensive record of the existing files and folders in the directory.





